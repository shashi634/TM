﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoBox.Models
{
    public class Profiles
    {
        public ObjectId Id { get; set; }
        [BsonElement("Name")]
        public string Name { get; set; }
        [BsonElement("Age")]
        public int Age { get; set; }
        [BsonElement("Address")]
        public string  Address { get; set; }
        [BsonElement("City")]
        public string City { get; set; }
        [BsonElement("MobileNo")]
        public decimal MobileNo { get; set; }
    }
}