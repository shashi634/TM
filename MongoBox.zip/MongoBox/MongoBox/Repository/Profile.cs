﻿using System;
using System.Collections.Generic;
using MongoBox.context;
using System.Linq;
using System.Web;
using MongoBox.Models;

namespace MongoBox.Repository
{
    public class Profile : IProfile
    {
        public readonly DbContext _DbContext;
        public Profile() {
            _DbContext = new DbContext();
        }

        public Profiles Create(Profiles studentProfile)
        {
            _DbContext._db.GetCollection<Profiles>("Profile").Save(studentProfile);
            return studentProfile;
        }

        public Profiles GetProfileById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Profiles> GetProfiles()
        {
          return _DbContext._db.GetCollection<Profiles>("Profile").FindAll();
        }
    }
}