﻿using MongoBox.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoBox.Repository
{
    interface IProfile
    {
        Profiles GetProfileById(int id);
        IEnumerable<Profiles> GetProfiles();

        Profiles Create(Profiles studentProfile);
    }
}
