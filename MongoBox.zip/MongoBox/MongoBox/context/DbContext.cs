﻿using MongoBox.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Collections.Generic;

namespace MongoBox.context
{
    public class DbContext
    {
        MongoClient _client;
        MongoServer _server;
        public MongoDatabase _db;

        public DbContext()
        {
            //mongodb://mongobox:PKparCBm69p7qM8FWtYcHD1AlEshY8s2bv26jTvXxa4NugHwS1C0blCoImhaFV4zbpH7akEylsLTc0bkSgiKfA==@mongobox.documents.azure.com:10255/?ssl=true&replicaSet=globaldb
            //mongodb://localhost:27017
            _client = new MongoClient("mongodb://mongobox:PKparCBm69p7qM8FWtYcHD1AlEshY8s2bv26jTvXxa4NugHwS1C0blCoImhaFV4zbpH7akEylsLTc0bkSgiKfA==@mongobox.documents.azure.com:10255/?ssl=true&replicaSet=globaldb");
#pragma warning disable CS0618 // Type or member is obsolete
            _server = _client.GetServer();
#pragma warning restore CS0618 // Type or member is obsolete
            _db = _server.GetDatabase("Student");
        }
    }
}