﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoBox.Repository;
using System.Net.Http;
using System.Web.Http;
using MongoBox.Models;

namespace MongoBox.Controllers
{
    public class StudentController : ApiController
    {
        Profile _profile;
        StudentController() {
            _profile = new Profile();
        }

        [Route("api/GetSudents")]
        [HttpGet]
        public IEnumerable<Profiles> GetStudents() {
            return _profile.GetProfiles();
        }

        [Route("api/CreateProfile")]
        [HttpPost]
        public Profiles CreateProfile(Profiles p)
        {
            return _profile.Create(p);
        }
    }
}
